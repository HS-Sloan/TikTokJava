package Tiktok;

public interface LikeA {
	void like(User user);
}

